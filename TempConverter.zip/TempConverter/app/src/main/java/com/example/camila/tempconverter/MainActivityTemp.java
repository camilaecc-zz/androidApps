package com.example.camila.tempconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import static android.app.ProgressDialog.show;

public class MainActivityTemp extends AppCompatActivity {
    Spinner spinner;
    Spinner spinner2;
    ArrayAdapter<CharSequence> adapter;
    private EditText tempin;
    private Button convert;
    private TextView result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_temp);
        spinner = (Spinner) findViewById(R.id.spinnerF);
        spinner2 = (Spinner) findViewById(R.id.spinnerT);
        adapter = ArrayAdapter.createFromResource(this,R.array.temps, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner2.setAdapter(adapter);

        tempin = (EditText) findViewById(R.id.input);
        convert = (Button) findViewById(R.id.button);
        result = (TextView) findViewById(R.id.Results);



        convert.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                String num = tempin.getText().toString();
                double n = Double.parseDouble(num);

                if(spinner.getSelectedItem().equals("Farenheit") && (!(n >= 0))){

                    Toast.makeText(getApplicationContext(), "Please enter a positive number" , Toast.LENGTH_LONG).show();
                }

                else if(spinner.getSelectedItem().equals(spinner2.getSelectedItem())){
                    Toast.makeText(getApplicationContext(), "No convertion needed" , Toast.LENGTH_LONG).show();

                }

                else if(spinner.getSelectedItem().equals("Farenheit") && spinner2.getSelectedItem().equals("Celcius") ){ //selection on spinner
                    result.setText(convertC(n));


                }else {
                    result.setText(convertF(n));

                }


            }
        });

    }
    public String convertC(double v){
        double r=  ((v - 32) * 5 / 9);
        String s =  Double.toString(r);
        return s;

    }
    public String convertF(double v){
        double r=  ((v * 9) / 5) + 32;
        String s =  Double.toString(r);
        return s;


    }
    }

