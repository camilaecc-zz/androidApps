package com.example.camila.timer;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {



        int counter;
        Button button, reset;
        TextView display;
        EditText time;
        String m;
        int min;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            button= (Button) findViewById(R.id.button);
            display = (TextView) findViewById(R.id.display);
            time= (EditText) findViewById(R.id.time);
            reset= (Button) findViewById(R.id.reset);

            reset.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    counter=0;
                    display.setText(String.valueOf(counter));
                    time.setText(" ");

                }

            });


            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    m = time.getText().toString();
                    min = (Integer.parseInt(m)) * 60000;

                            new CountDownTimer(min, 1000) {
                            public void onTick(long millisUntilFinished) {
                                display.setText(String.valueOf(counter));
                                counter++;
                            }

                            public void onFinish() {

                                display.setText("FINISH!!");
                            }
                        }.start();



                }

            });



        }
    }


