package com.example.camila.counter;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button button;
    public final String SPREF = "SHAREDPREF";
    public final String COUNT = "COUNT";
    private int count=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences settings = getSharedPreferences(SPREF, 0);
        button = (Button)findViewById(R.id.button);
        count = settings.getInt(COUNT, 0);
        button.setText(count + "");

    }
    protected void onPause(){
        super.onPause();
        SharedPreferences settings = getSharedPreferences(SPREF, 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt(COUNT, count);

        editor.commit();
    }
    public void count(View v){
        count += 1;
        button.setText(count + "");

    }

}
