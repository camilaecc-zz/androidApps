package com.example.hryhoriipertaya.vladsmidtermtry;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class desc extends AppCompatActivity {

    String[] citiesNames;
    String[] citiesDesc;
    String[] citiesWeather;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_desc);



        citiesNames = getApplication().getResources().getStringArray(R.array.cities);
        citiesDesc = getApplication().getResources().getStringArray(R.array.desc);
        citiesWeather = getApplication().getResources().getStringArray(R.array.weather);

        TextView cityName = (TextView) findViewById(R.id.nameTV);
        TextView cityDesc = (TextView) findViewById(R.id.descTV);
        TextView cityWeather = (TextView) findViewById(R.id.weatherTV);


        cityName.setText(citiesNames[getIntent().getIntExtra("position1", 0)]);
        cityDesc.setText(citiesDesc[getIntent().getIntExtra("position1", 0)]);
        cityWeather.setText(citiesWeather[getIntent().getIntExtra("position1", 0)]);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent main = new Intent(this,MainActivity.class);
        startActivity(main);
        finish();
    }
}
