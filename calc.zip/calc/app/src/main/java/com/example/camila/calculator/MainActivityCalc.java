package com.example.camila.calculator;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;

public class MainActivityCalc extends AppCompatActivity {

    private Button one, two, three, four, five, six, seven, eight, nine, zero;
    private Button plus, subtract, divide, multiply;
    private Button ac, dot, equal;
    private TextView outputResult;
    DecimalFormat formatt = new DecimalFormat("#0.0000");


    double n1, n2 = 0, res;
    boolean xp = false, xmin = false, xm = false, xd = false;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_calc);

        outputResult = (TextView) findViewById(R.id.display);
        outputResult.setText("");
        one = (Button) findViewById(R.id.one);
        two = (Button) findViewById(R.id.two);
        three = (Button) findViewById(R.id.three);
        four = (Button) findViewById(R.id.four);
        five = (Button) findViewById(R.id.five);
        six = (Button) findViewById(R.id.six);
        seven = (Button) findViewById(R.id.seven);
        eight = (Button) findViewById(R.id.eight);
        nine = (Button) findViewById(R.id.nine);
        zero = (Button) findViewById(R.id.zero);
        plus = (Button) findViewById(R.id.plus);
        subtract = (Button) findViewById(R.id.subtract);
        divide = (Button) findViewById(R.id.divide);
        multiply = (Button) findViewById(R.id.multiply);
        ac = (Button) findViewById(R.id.ac);
        dot = (Button) findViewById(R.id.dot);
        equal = (Button) findViewById(R.id.equal);


        one.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outputResult.setText(outputResult.getText() + "1");
            }
        });

        two.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outputResult.setText(outputResult.getText() + "2");
            }
        });

        three.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outputResult.setText(outputResult.getText() + "3");
            }
        });

        four.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outputResult.setText(outputResult.getText() + "4");
            }
        });

        five.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outputResult.setText(outputResult.getText() + "5");
            }
        });

        six.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outputResult.setText(outputResult.getText() + "6");
            }
        });

        seven.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outputResult.setText(outputResult.getText() + "7");
            }
        });

        eight.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outputResult.setText(outputResult.getText() + "8");
            }
        });

        nine.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outputResult.setText(outputResult.getText() + "9");
            }
        });

        zero.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outputResult.setText(outputResult.getText() + "0");
            }
        });

        plus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (outputResult == null) {
                    outputResult.setText("");

                } else {
                    n1 = Double.parseDouble(outputResult.getText() + "");
                    calc(xp);
                    xp = true;
                    outputResult.setText(null);


                }
            }
        });

        subtract.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                n1 = Double.parseDouble(outputResult.getText() + "");
                calc(xmin);
                xmin = true;
                outputResult.setText(null);


            }
        });

        divide.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                n1 = Double.parseDouble(outputResult.getText() + "");
                xd = true;
                calc(xd);
                outputResult.setText(null);
            }
        });
        multiply.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                n1 = Double.parseDouble(outputResult.getText() + "");
                xm = true;
                calc(xm);
                outputResult.setText(null);
            }
        });

        equal.setOnClickListener(new View.OnClickListener() {
                                     public void onClick(View v) {

                                         n2 = Double.parseDouble(outputResult.getText() + "");
                                          if (xp == true) {
                                             res = n1 + n2;
                                             outputResult.setText(res + "");
                                             xp = false;

                                         } else if (xmin == true) {
                                             res = n1 - n2;
                                             if ((res % 1) != 0) {
                                                 outputResult.setText(formatt.format(res) + "");
                                                 xd = false;
                                             } else {
                                                 outputResult.setText(res + "");
                                                 xd = false;
                                             }

                                         } else if (xm == true) {
                                             res = n1 * n2;
                                             outputResult.setText(res + "");
                                             xm = false;

                                         } else if (xd == true) {
                                             if (n2 == 0) {
                                                 Toast.makeText(getApplicationContext(), "Cannot dived 0", Toast.LENGTH_LONG).show();
                                                 outputResult.setText(n1 + "");
                                             } else {
                                                 res = n1 / n2;
                                                 if (n1 % n2 != 0) {
                                                     outputResult.setText(formatt.format(res) + "");
                                                     xd = false;
                                                 } else {
                                                     outputResult.setText(res + "");
                                                     xd = false;
                                                 }
                                             }

                                         }else{

                                                 Toast.makeText(getApplicationContext(), "Select a number ", Toast.LENGTH_LONG).show();
                                         }
                                     }
                                 }
        );

        ac.setOnClickListener(new View.OnClickListener() {
                                  public void onClick(View v) {
                                      outputResult.setText("");
                                  }
                              }
        );

        dot.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                outputResult.setText(outputResult.getText() + ".");
            }
        });
    }

    public void calc(boolean x) {
        n2 = Double.parseDouble(outputResult.getText() + "");

        if (x == true) {
            res = n1 + n2;
            outputResult.setText(res + "");
            xp = false;

        } else if (x == true) {
            res = n1 - n2;
            if ((res % res) == 0) {
                outputResult.setText(res + "");
                xd = false;
            } else {
                outputResult.setText(formatt.format(res) + "");
                xd = false;

            }


        } else if (x == true) {
            res = n1 * n2;
            outputResult.setText(res + "");
            xm = false;

        } else if (x == true) {
            if (n2 == 0) {
                Toast.makeText(getApplicationContext(), "Cannot dived 0", Toast.LENGTH_LONG).show();
                outputResult.setText(n1 + "");
            } else {

                res = n1 / n2;
                if (n1 % n2 != 0) {
                    outputResult.setText(formatt.format(res) + "");
                    xd = false;
                } else {
                    outputResult.setText(res + "");
                    xd = false;
                }

            }

        }
    }

}




