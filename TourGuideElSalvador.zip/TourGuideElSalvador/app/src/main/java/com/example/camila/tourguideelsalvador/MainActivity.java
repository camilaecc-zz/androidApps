package com.example.camila.tourguideelsalvador;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements Fragment_A.OnFragmentInteractionListener, Fragment_B.OnFragmentInteractionListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public void onFragmentInteraction(String data) {
        FragmentManager FragManager = getSupportFragmentManager();
        Fragment_B fragmentB = (Fragment_B) FragManager.findFragmentById(R.id.fragment_b);
        fragmentB.updateText(data);
    }
}
