package com.example.camila.tourguideelsalvador;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by Camila on 10/11/17.
 */



    public class Fragment_B extends Fragment {
        // TODO: Rename parameter arguments, choose names that match
        // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
        private static final String ARG_PARAM1 = "param1";
        private static final String ARG_PARAM2 = "param2";
        TextView My_txt;
        // TODO: Rename and change types of parameters
        private String mParam1;
        private String mParam2;

        private OnFragmentInteractionListener mListener;

        public Fragment_B() {

        }


        public static Fragment_B newInstance(String param1, String param2) {
            Fragment_B fragment = new Fragment_B();
            Bundle args = new Bundle();
            args.putString(ARG_PARAM1, param1);
            args.putString(ARG_PARAM2, param2);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            if (getArguments() != null) {
                mParam1 = getArguments().getString(ARG_PARAM1);
                mParam2 = getArguments().getString(ARG_PARAM2);
            }
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {

            return inflater.inflate(R.layout.fragment_b, container, false);
        }

        @Override
        public void onActivityCreated(Bundle savedInstanceState) {
            super.onActivityCreated(savedInstanceState);
            My_txt = (TextView)getActivity().findViewById(R.id.displayyy);
            My_txt.setMovementMethod(new ScrollingMovementMethod());
            if (savedInstanceState == null){
                My_txt.setText("Welcome to El Salvador tourguide");
            }else{
                My_txt.setText(savedInstanceState.getString("city", ""));
            }
        }

        @Override
        public void onAttach(Context context) {
            super.onAttach(context);
            if (context instanceof OnFragmentInteractionListener) {
                mListener = (OnFragmentInteractionListener) context;
            } else {
                throw new RuntimeException(context.toString()
                        + " must implement OnFragmentInteractionListener");
            }
        }

        @Override
        public void onDetach() {
            super.onDetach();
            mListener = null;
        }

        public void updateText(String data){
            if (data.equals(null)){
                My_txt.setText("Welcome to El Salvador tourguide");
            }else {
                Resources res = getResources();
                String [] cities = res.getStringArray(R.array.desc);
                switch (data) {

                    case "Beach":
                        My_txt.setText(cities[0]);
                        break;
                    case "Volcanoe":
                        My_txt.setText(cities[1]);
                        break;
                    case "City":
                        My_txt.setText(cities[2]);
                        break;
                }
            }


        }

        public interface OnFragmentInteractionListener {
            // TODO: Update argument type and name
            void onFragmentInteraction(String data);
        }
    }


